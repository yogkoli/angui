import { Component, ViewChild } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { FormGroup, FormControl } from '@angular/forms';
import { catchError, map } from 'rxjs/operators';
import { throwError } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
    title = 'Welcome to Angular';
    subtitle = '.NET Core + Angular CLI v6 + Bootstrap & FontAwesome + Swagger Template';

    profileForm = new FormGroup({
        fileinput: new FormControl(''),
        name: new FormControl(''),
        workflowcode: new FormControl(''),
    });

    submitted = false;

    @ViewChild('file') file;
    public files: Set<File> = new Set();

    constructor(private http: HttpClient) { }

    onFilesAdded() {
        const files: { [key: string]: File } = this.file.nativeElement.files;
        for (let key in files) {
            if (!isNaN(parseInt(key))) {
                this.files.add(files[key]);
            }
        }
    }

    onSubmit() {
        console.warn(this.profileForm.value);
        this.http.get("/api/data/")
            .pipe(catchError(this.logError))
            .subscribe(data => {
                // Handle the updated data here.
                console.log(data);
            });

        const formdata: FormData = new FormData();

        this.files.forEach(file => {
            console.log(file.name);
            formdata.append(file.name, file, file.name);
            
        });

        for (const field in this.profileForm.controls) {
            const control = this.profileForm.get(field);
            formdata.append(field, control.value);
            console.log(field);
            console.log(control.value);
        }
        

        this.http.post("/api/data/",
            formdata, )
            .pipe(catchError(this.logError))
            .subscribe(data => {
                // Handle the updated data here.
                console.log(data);
                let app = data as Apple;
                this.profileForm.get("name").setValue(app);
            });


        return;
    }

    logError(err: HttpErrorResponse)
    {
        return throwError(err);
    }

}

export class Apple {
    public seeds: any;
    public color: any;

} 
